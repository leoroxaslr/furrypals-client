// fetch("https://dummyjson.com/productsss")
//   .then((res) => {
//     console.log(res.status);
//     if (res.status === 200) {
//       return res.json();
//     } else {
//       console.log("Error: " + res.statusText);
//       return res.status;
//     }
//   })
//   .then(console.log)
//   .catch((error) => {
//     console.log(error);
//   });

async function init() {
  async function getProducts() {
    try {
      const response = await fetch("https://dummyjson.com/productss");
      const data = await response.json();
      return data;
    } catch {
      return "Something went wrong";
      // console.log(error.message);
      // return error;
    }
  }

  console.log(await getProducts());
}

init();
